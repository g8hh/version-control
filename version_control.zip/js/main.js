var player = new Player();

loadUp();
gameLoop();
updateNewsticker();